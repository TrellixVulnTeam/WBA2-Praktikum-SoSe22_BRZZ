document.write('\
<div class="header">\
<table class ="table_header">\
    <tr>\
        <th class="border">\
            <a href="./home.html"><img id="Logo" src="./lib/logo2.png" align="left" alt="Logo"></a>\
            <h1 class="welcome">Welcome!</h1>\
        </th>\
        <th class="border">\
            <div>\
                <input class="search" type="text" placeholder="Search">\
            </div>\
        </th>\
        <th class="border">\
            <a href="profile.html"><img id="Profil" src="./lib/profil.png" alt="Profil"></a>\
        </th>\
        <th class="border">\
            <nav>\
                <div class="dropdown">\
                    <button class="dropbtn">Menu</button>\
                    <div class="dropdown-content">\
                    <a href="home.html">Home</a>\
                    <a href="questionSide.html">Ask Question</a>\
                    <a href="kategorie.html">Categories</a>\
                    <a href="login.html">Log in</a>\
                    <a href="signup.html">Sign up</a>\
                    </div>\
                </div>\
            </nav>\
        </th>\
    </tr>\
</table>\
</div>\
');